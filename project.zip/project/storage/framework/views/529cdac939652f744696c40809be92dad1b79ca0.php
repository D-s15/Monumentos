
 
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-11">
            <h2>Add New Monument</h2>
        </div>
        <div class="col-lg-1">
            <a class="btn btn-primary" href="<?php echo e(url('monument')); ?>"> Back</a>
        </div>
    </div>
 
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <form action="<?php echo e(route('monument.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="name">Name:</label>
            <input type="text" class="form-control" id="name" placeholder="Enter Monument Name" name="name">
        </div>
        <div class="form-group">
            <label for="description">Description:</label>
            <input type="text" class="form-control" id="description" placeholder="Enter Monument Description" name="description">
        </div>
        <div class="form-group">
            <label for="image">Image:</label>
            <input type="url" class="form-control" id="image" name="image" placeholder="Enter Monument Image URL"></textarea>
        </div>
       <div class="form-group">
            <label for="schedule_am">Morning Schedule:</label>
            <input type="text" class="form-control" id="schedule_am" placeholder="Enter Monument Morning Schedule" name="schedule_am">
        </div> <div class="form-group">
            <label for="schedule_pm">Afternoon Schedule:</label>
            <input type="text" class="form-control" id="schedule_pm" placeholder="Enter Monument Afternoon Schedule" name="schedule_pm">
        </div>
        <div class="form-group">
            <label for="closing">Closing:</label>
            <input type="text" class="form-control" id="closing" placeholder="Enter Monument Closing" name="closing">
        </div>
        <button type="submit" class="btn btn-default">Submit</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('monument.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Luis\Desktop\PAS\project\resources\views/monument/create.blade.php ENDPATH**/ ?>