
 
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-11">
            <h2>Update Point</h2>
        </div>
        <div class="col-lg-1">
            <a class="btn btn-primary" href="<?php echo e(url('point')); ?>"> Back</a>
        </div>
    </div>
 
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <form method="post" action="<?php echo e(route('point.update',$point->id)); ?>" >
        <?php echo method_field('PATCH'); ?>
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="monument_id">Point Name:</label>
            <input type="number" class="form-control" id="monument_id" placeholder="Enter Id Of The Monument This Point Belongs To" name="monument_id" value="<?php echo e($point->monument_id); ?>">
        </div>
        <div class="form-group">
            <label for="name">Name:</label>
            <input type="text" class="form-control" id="name" placeholder="Enter Point Name" name="name" value="<?php echo e($point->name); ?>">
        </div>
        <div class="form-group">
            <label for="description">Description:</label>
            <input type="text" class="form-control" id="description" placeholder="Enter Point Description" name="description" value="<?php echo e($point->description); ?>">
        
        <div class="form-group">
            <label for="image">Point Image:</label>
            <input type="url" class="form-control" id="image" placeholder="Enter Point Image URL" name="image" value="<?php echo e($point->image); ?>">
        </div>
        <button type="submit" class="btn btn-default">Submit</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('point.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Luis\Desktop\PAS\project\resources\views/point/edit.blade.php ENDPATH**/ ?>