
 
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-11">
            <h2>Update Student</h2>
        </div>
        <div class="col-lg-1">
            <a class="btn btn-primary" href="<?php echo e(url('monument')); ?>"> Back</a>
        </div>
    </div>
 
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <form method="post" action="<?php echo e(route('monument.update',$monument->id)); ?>" >
        <?php echo method_field('PATCH'); ?>
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="name">Monument Name:</label>
            <input type="text" class="form-control" id="name" placeholder="Enter Monument Name" name="name" value="<?php echo e($monument->name); ?>">
        </div>
        <div class="form-group">
            <label for="description">Description:</label>
            <input type="text" class="form-control" id="description" placeholder="Enter Monument Description" name="description" value="<?php echo e($monument->description); ?>">
        </div>
        <div class="form-group">
            <label for="image">Monument Image:</label>
            <input type="url" class="form-control" id="image" placeholder="Enter Monument Image URL" name="image" value="<?php echo e($monument->image); ?>">
        </div>
        <div class="form-group">
            <label for="schedule_am">Morning Schedule:</label>
            <input type="text" class="form-control" id="schedule_am" placeholder="Enter Monument Morning Schedule" name="schedule_am" value="<?php echo e($monument->schedule_am); ?>">
        </div>
        <div class="form-group">
            <label for="schedule_pm">Afternoon Schedule:</label>
            <input type="text" class="form-control" id="schedule_pm" placeholder="Enter Monument Afternoon Schedule" name="schedule_pm" value="<?php echo e($monument->schedule_pm); ?>">
        </div>
        <div class="form-group">
            <label for="closing">Closing:</label>
            <input type="text" class="form-control" id="closing" placeholder="Enter Monument Closing Day" name="closing" value="<?php echo e($monument->closing); ?>">
        </div>
        <button type="submit" class="btn btn-default">Submit</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('monument.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Luis\Desktop\PAS\project\resources\views/monument/edit.blade.php ENDPATH**/ ?>