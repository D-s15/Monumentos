
 
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-11">
                <h2>View Points</h2>
        </div>
        <div class="col-lg-1">
            <a class="btn btn-primary" href="<?php echo e(url('point')); ?>"> Back</a>
        </div>
    </div>
    <table class="table table-bordered">
        <tr>
            <th>monument_id:</th>
            <td><?php echo e($point->monument_id); ?></td>
        </tr>
        <tr>
            <th>name:</th>
            <td><?php echo e($point->name); ?></td>
        </tr>
        <tr>
            <th>description:</th>
            <td><?php echo e($point->description); ?></td>
        </tr>
        <tr>
            <th>Image:</th>
            <td><img src="<?php echo e($point->image); ?>" alt="Monument image" width="100"/></td>
        </tr>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('point.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Luis\Desktop\PAS\project\resources\views/point/view.blade.php ENDPATH**/ ?>