
 
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-11">
                <h2>View Monuments</h2>
        </div>
        <div class="col-lg-1">
            <a class="btn btn-primary" href="<?php echo e(url('monument')); ?>"> Back</a>
        </div>
    </div>
    <table class="table table-bordered">
        <tr>
            <th>Name:</th>
            <td><?php echo e($monument->name); ?></td>
        </tr>
        <tr>
            <th>Description:</th>
            <td><?php echo e($monument->description); ?></td>
        </tr>
        <tr>
            <th>Image:</th>
            <td><img src="<?php echo e($monument->image); ?>" alt="Monument image" width="100"/></td>
        </tr>
        <tr>
            <th>Morning Schedule:</th>
            <td><?php echo e($monument->schedule_am); ?></td>
        </tr>
        <tr>
            <th>Afternoon Schedule:</th>
            <td><?php echo e($monument->schedule_pm); ?></td>
        </tr>
        <tr>
            <th>Closing:</th>
            <td><?php echo e($monument->closing); ?></td>
        </tr>
 
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('monument.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Luis\Desktop\PAS\project\resources\views/monument/view.blade.php ENDPATH**/ ?>