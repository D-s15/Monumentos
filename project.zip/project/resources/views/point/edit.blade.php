@extends('point.layouts.app')
 
@section('content')
    <div class="row">
        <div class="col-lg-11">
            <h2>Update Point</h2>
        </div>
        <div class="col-lg-1">
            <a class="btn btn-primary" href="{{ url('point') }}"> Back</a>
        </div>
    </div>
 
    @if ($errors->any())
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif
    <form method="post" action="{{ route('point.update',$point->id) }}" >
        @method('PATCH')
        @csrf
        <div class="form-group">
            <label for="monument_id">Point Name:</label>
            <input type="number" class="form-control" id="monument_id" placeholder="Enter Id Of The Monument This Point Belongs To" name="monument_id" value="{{ $point->monument_id }}">
        </div>
        <div class="form-group">
            <label for="name">Name:</label>
            <input type="text" class="form-control" id="name" placeholder="Enter Point Name" name="name" value="{{ $point->name }}">
        </div>
        <div class="form-group">
            <label for="description">Description:</label>
            <input type="text" class="form-control" id="description" placeholder="Enter Point Description" name="description" value="{{ $point->description }}">
        
        <div class="form-group">
            <label for="image">Point Image:</label>
            <input type="url" class="form-control" id="image" placeholder="Enter Point Image URL" name="image" value="{{ $point->image }}">
        </div>
        <button type="submit" class="btn btn-default">Submit</button>
    </form>
@endsection