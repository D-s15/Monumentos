@extends('point.layouts.app')
 
@section('content')
    <div class="row">
        <div class="col-lg-11">
            <h2>Add New Point</h2>
        </div>
        <div class="col-lg-1">
            <a class="btn btn-primary" href="{{ url('point') }}"> Back</a>
        </div>
    </div>
 
    @if ($errors->any())
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif
    <form action="{{ route('point.store') }}" method="POST">
        @csrf
        <div class="form-group">
            <label for="monument_id">Name:</label>
            <input type="number" class="form-control" id="monument_id" placeholder="Enter The Id Of The Monument This Point Belongs To" name="monument_id">
        </div>
        <div class="form-group">
            <label for="name">Name:</label>
            <input type="text" class="form-control" id="name" placeholder="Enter Point name" name="name">
        </div>
        <div class="form-group">
            <label for="description">Description:</label>
            <input type="text" class="form-control" id="description" name="description" placeholder="Enter Point Description">
        </div>
       <div class="form-group">
            <label for="image">Point image:</label>
            <input type="URL" class="form-control" id="image" placeholder="Enter Point Image URL" name="image">
        </div>
        <button type="submit" class="btn btn-default">Submit</button>
    </form>
@endsection