@extends('point.layouts.app')
 
@section('content')
    <div class="row">
        <div class="col-lg-11">
                <h2>View Points</h2>
        </div>
        <div class="col-lg-1">
            <a class="btn btn-primary" href="{{ url('point') }}"> Back</a>
        </div>
    </div>
    <table class="table table-bordered">
        <tr>
            <th>monument_id:</th>
            <td>{{ $point->monument_id }}</td>
        </tr>
        <tr>
            <th>name:</th>
            <td>{{ $point->name }}</td>
        </tr>
        <tr>
            <th>description:</th>
            <td>{{ $point->description }}</td>
        </tr>
        <tr>
            <th>Image:</th>
            <td><img src="{{ $point->image }}" alt="Monument image" width="100"/></td>
        </tr>
    </table>
@endsection