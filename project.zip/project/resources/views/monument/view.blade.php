@extends('monument.layouts.app')
 
@section('content')
    <div class="row">
        <div class="col-lg-11">
                <h2>View Monuments</h2>
        </div>
        <div class="col-lg-1">
            <a class="btn btn-primary" href="{{ url('monument') }}"> Back</a>
        </div>
    </div>
    <table class="table table-bordered">
        <tr>
            <th>Name:</th>
            <td>{{ $monument->name }}</td>
        </tr>
        <tr>
            <th>Description:</th>
            <td>{{ $monument->description }}</td>
        </tr>
        <tr>
            <th>Image:</th>
            <td><img src="{{ $monument->image }}" alt="Monument image" width="100"/></td>
        </tr>
        <tr>
            <th>Morning Schedule:</th>
            <td>{{ $monument->schedule_am }}</td>
        </tr>
        <tr>
            <th>Afternoon Schedule:</th>
            <td>{{ $monument->schedule_pm }}</td>
        </tr>
        <tr>
            <th>Closing:</th>
            <td>{{ $monument->closing }}</td>
        </tr>
 
    </table>
@endsection