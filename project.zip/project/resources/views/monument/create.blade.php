@extends('monument.layouts.app')
 
@section('content')
    <div class="row">
        <div class="col-lg-11">
            <h2>Add New Monument</h2>
        </div>
        <div class="col-lg-1">
            <a class="btn btn-primary" href="{{ url('monument') }}"> Back</a>
        </div>
    </div>
 
    @if ($errors->any())
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif
    <form action="{{ route('monument.store') }}" method="POST">
        @csrf
        <div class="form-group">
            <label for="name">Name:</label>
            <input type="text" class="form-control" id="name" placeholder="Enter Monument Name" name="name">
        </div>
        <div class="form-group">
            <label for="description">Description:</label>
            <input type="text" class="form-control" id="description" placeholder="Enter Monument Description" name="description">
        </div>
        <div class="form-group">
            <label for="image">Image:</label>
            <input type="url" class="form-control" id="image" name="image" placeholder="Enter Monument Image URL"></textarea>
        </div>
       <div class="form-group">
            <label for="schedule_am">Morning Schedule:</label>
            <input type="text" class="form-control" id="schedule_am" placeholder="Enter Monument Morning Schedule" name="schedule_am">
        </div> <div class="form-group">
            <label for="schedule_pm">Afternoon Schedule:</label>
            <input type="text" class="form-control" id="schedule_pm" placeholder="Enter Monument Afternoon Schedule" name="schedule_pm">
        </div>
        <div class="form-group">
            <label for="closing">Closing:</label>
            <input type="text" class="form-control" id="closing" placeholder="Enter Monument Closing" name="closing">
        </div>
        <button type="submit" class="btn btn-default">Submit</button>
    </form>
@endsection