<?php

namespace App\Http\Controllers;

use App\Models\Monument;
use Illuminate\Http\Request;

class MonumentwebController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $monuments = Monument::all();
        return view('monument.list', compact('monuments'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view('monument.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $request->validate([
            'name'=>'required',
            'description'=> 'required',
            'image' => 'required',
            'schedule_am' => 'required',
            'schedule_pm' => 'required',
            'closing' => 'required'
        ]);
 
        $monument = new Monument([
            'name' => $request->get('name'),
            'description'=> $request->get('description'),
            'image'=> $request->get('image'),
            'schedule_am'=> $request->get('schedule_am'),
            'schedule_pm'=> $request->get('schedule_pm'),
            'closing'=> $request->get('closing')
        ]);

        $monument->save();
        return redirect('/monument')->with('success', 'Monument has been added');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Monument  $monument
     * @return \Illuminate\Http\Response
     */
    public function show(Monument $monument)
    {
        //
        return view('monument.view',compact('monument'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Monument  $monument
     * @return \Illuminate\Http\Response
     */
    public function edit(Monument $monument)
    {
        //
        return view('monument.edit',compact('monument'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Monument  $monument
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $request->validate([
            'name'=>'required',
            'description'=> 'required',
            'image' => 'required',
            'schedule_am' => 'required',
            'schedule_pm' => 'required',
            'closing' => 'required'
        ]);
 
        $monument = Monument::find($id);
        $monument->name = $request->get('name');
        $monument->description = $request->get('description');
        $monument->image = $request->get('image');
        $monument->schedule_am = $request->get('schedule_am');
        $monument->schedule_pm = $request->get('schedule_pm');
        $monument->closing = $request->get('closing');
 
        $monument->update();
 
        return redirect('/monument')->with('success', 'Monument updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Monument  $monument
     * @return \Illuminate\Http\Response
     */
    public function destroy(Monument $monument)
    {
        //
        $monument->delete();
        return redirect('/monument')->with('success', 'Monument deleted successfully');
    }
}
